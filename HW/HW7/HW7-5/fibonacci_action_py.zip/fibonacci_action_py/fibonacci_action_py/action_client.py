import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from fibonacci_interface.action import MyFibonacci


class MyFibonacciActionClient(Node):

    def __init__(self):
        super().__init__('my_fibonacci_action_client')
        self._action_client = ActionClient(self, MyFibonacci, 'my_fibonacci')

    def send_goal(self, order):
        self._action_client.wait_for_server()

        goal_msg = MyFibonacci.Goal()
        goal_msg.order = order

        self.get_logger().info(f'Sending goal request: order = {order}')
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback
        )
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected 😢')
            return

        self.get_logger().info('Goal accepted 😊')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(f'Feedback: {feedback.partial_sequence}')

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'Result: {result.sequence}')
        rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    action_client = MyFibonacciActionClient()
    action_client.send_goal(10)
    rclpy.spin(action_client)


if __name__ == '__main__':
    main()
