from setuptools import find_packages, setup

package_name = 'fibonacci_action_py'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ray2bot',
    maintainer_email='ray2bot@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'action_server = fibonacci_action_py.action_server:main',
            'action_client = fibonacci_action_py.action_client:main',
        ],
    },
)
