import rclpy
from rclpy.node import Node
from motor_status_interfaces.srv import MotorStatusSrv

class MotorClient(Node):
    def __init__(self):
        super().__init__('motor_client')
        self.cli = self.create_client(MotorStatusSrv, 'get_motor_status')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('⏳ Waiting for Motor Server...')
        self.req = MotorStatusSrv.Request()

    def send_request(self):
        self.req.request_msg = "status"
        return self.cli.call_async(self.req)


def main(args=None):
    rclpy.init(args=args)
    node = MotorClient()

    future = node.send_request()
    rclpy.spin_until_future_complete(node, future)

    if future.result() is not None:
        node.get_logger().info(f'💡 Motor Status: {future.result().motor_status}')
    else:
        node.get_logger().error('❌ Service call failed.')

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
