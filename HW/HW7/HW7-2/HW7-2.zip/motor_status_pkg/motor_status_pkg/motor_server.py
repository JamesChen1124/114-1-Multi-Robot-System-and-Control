import rclpy
from rclpy.node import Node
from motor_status_interfaces.srv import MotorStatusSrv
import serial, time

class MotorServer(Node):
    def __init__(self):
        super().__init__('motor_server')
        self.srv = self.create_service(MotorStatusSrv, 'get_motor_status', self.callback)

        try:
            self.arduino = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
            time.sleep(2)
            self.get_logger().info('✅ Connected to Arduino')
        except Exception as e:
            self.get_logger().error(f'Failed to connect to Arduino: {e}')
            self.arduino = None

    def callback(self, request, response):
        if not self.arduino:
            response.motor_status = "ERROR"
            return response

        self.arduino.write(b'STATUS\n')
        time.sleep(0.1)
        line = self.arduino.readline().decode('utf-8').strip()

        if line in ["ON", "OFF"]:
            response.motor_status = line
        else:
            response.motor_status = "UNKNOWN"

        self.get_logger().info(f'Motor status: {response.motor_status}')
        return response


def main(args=None):
    rclpy.init(args=args)
    node = MotorServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
