from setuptools import find_packages, setup

package_name = 'my_pubsub_srvcli'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ray2bot',
    maintainer_email='ray2bot@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
           'pub_speed = my_pubsub_srvcli.pub_speed:main',
           'sub_speed = my_pubsub_srvcli.sub_speed:main',
           'srv_money_server = my_pubsub_srvcli.srv_money_server:main',
           'srv_money_client = my_pubsub_srvcli.srv_money_client:main',
        ],
    },
)
