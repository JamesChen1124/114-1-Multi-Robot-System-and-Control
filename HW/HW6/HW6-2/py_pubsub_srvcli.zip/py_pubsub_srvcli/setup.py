from setuptools import find_packages, setup

package_name = 'py_pubsub_srvcli'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jameschen',
    maintainer_email='jameschen@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        	'num_pub = py_pubsub_srvcli.num_publisher:main',
        	'num_sub = py_pubsub_srvcli.num_subscriber:main',
        	'add3_server = py_pubsub_srvcli.add_three_ints_server:main',
        	'add3_client = py_pubsub_srvcli.add_three_ints_client:main',
        ],
    },
)
